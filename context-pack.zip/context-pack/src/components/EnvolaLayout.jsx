import React from "react";
import { Helmet } from "react-helmet-async";

export default function EnvolaLayout({ children }) {
  return (
    <>
      <Helmet>
        {/* Optional but good: speed up Google Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />

        {/* Load Poppins only on Envola pages */}
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
        />
      </Helmet>

      {children}
    </>
  );
}
