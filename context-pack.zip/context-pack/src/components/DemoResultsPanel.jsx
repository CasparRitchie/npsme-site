// src/components/DemoResultsPanel.jsx
import React from "react";

const STAGES = [
  "Overall NPS",
  "Online experience",
  "Ordering",
  "Delivery",
  "In-store support",
  "Returns",
  // "Cease / leaving",
];

const STOP_WORDS = new Set([
  "the","and","for","with","this","that","you","your","our","are","was","were",
  "is","it","to","of","in","on","at","a","an","i","we","they","but","so","very",
  "really","just","too","be","have","had","has","as","if","or"
]);

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

// Helpers to group by period
function getMonthKey(date) {
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "Unknown";
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  return `${y}-${String(m).padStart(2, "0")}`;
}

function getQuarterKey(date) {
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "Unknown";
  const y = d.getFullYear();
  const q = Math.floor(d.getMonth() / 3) + 1;
  return `${y} Q${q}`;
}

function computeNpsStats(responses) {
  if (!responses.length) {
    return { nps: null, total: 0, promoters: 0, passives: 0, detractors: 0 };
  }

  let promoters = 0;
  let passives = 0;
  let detractors = 0;

  for (const r of responses) {
    if (typeof r.score !== "number" || Number.isNaN(r.score)) continue;
    if (r.score >= 9) promoters++;
    else if (r.score >= 7) passives++;
    else detractors++;
  }

  const total = promoters + passives + detractors;
  if (!total) {
    return { nps: null, total, promoters, passives, detractors };
  }

  const nps = Math.round(((promoters - detractors) / total) * 100);
  return { nps, total, promoters, passives, detractors };
}

function buildWordCloudData(responses, maxWords = 30) {
  const counts = new Map();

  for (const r of responses) {
    const text = (r.comment || r.verbatim || "").toLowerCase();
    if (!text) continue;

    const words = text.replace(/[^a-z0-9\s]/gi, " ").split(/\s+/);
    for (const wRaw of words) {
      const w = wRaw.trim();
      if (!w || STOP_WORDS.has(w) || w.length <= 2) continue;
      counts.set(w, (counts.get(w) || 0) + 1);
    }
  }

  const items = Array.from(counts.entries())
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, maxWords);

  if (!items.length) return [];

  const maxCount = items[0].count;
  const minCount = items[items.length - 1].count;

  return items.map(({ word, count }) => {
    const ratio =
      maxCount === minCount ? 1 : (count - minCount) / (maxCount - minCount);
    const fontSize = 0.8 + ratio * 1.0; // 0.8–1.8rem
    return { word, count, fontSize };
  });
}

export default function DemoResultsPanel() {
  const [responses, setResponses] = React.useState([]);
  const [loadingResults, setLoadingResults] = React.useState(false);
  const [resultsError, setResultsError] = React.useState("");
  const [customerFilter, setCustomerFilter] = React.useState("ALL");
  const [companyFilter, setCompanyFilter] = React.useState("ALL");
  const [period, setPeriod] = React.useState("monthly"); // 'monthly' | 'quarterly' | 'rolling12'
  const [resultType, setResultType] = React.useState("ALL"); // ALL | OVERALL | MILESTONE
  const [stageFilter, setStageFilter] = React.useState("ALL");

  const [inviteSummary, setInviteSummary] = React.useState(null);
  const [loadingInvites, setLoadingInvites] = React.useState(false);
  const [inviteError, setInviteError] = React.useState("");

  // Load results from backend
  async function loadResults() {
    try {
      setLoadingResults(true);
      setResultsError("");

      const res = await fetch("/api/demo-responses");
      if (!res.ok) {
        throw new Error("Server returned an error");
      }

      const data = await res.json();
      setResponses(data.rows || []);
    } catch (err) {
      console.error("Error loading demo responses", err);
      setResultsError("We couldn’t load demo results. Please try again in a moment.");
    } finally {
      setLoadingResults(false);
    }
  }

  async function loadInvitationSummary() {
    try {
      setLoadingInvites(true);
      setInviteError("");

      const params = new URLSearchParams();

      if (customerFilter !== "ALL") {
        params.set("customer", customerFilter);
      }
      if (companyFilter !== "ALL") {
        params.set("company", companyFilter);
      }
      if (stageFilter !== "ALL") {
        params.set("stage", stageFilter);
      }

      const qs = params.toString();
      const url = qs ? `/api/demo-funnel?${qs}` : "/api/demo-funnel";

      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();
      setInviteSummary(data);
    } catch (err) {
      console.error("Error loading invitation summary", err);
      setInviteError("We couldn’t load invitation stats. Please try again in a moment.");
    } finally {
      setLoadingInvites(false);
    }
  }

  // Load raw responses once on mount
  React.useEffect(() => {
    loadResults();
  }, []);

  // Reload invitation summary whenever global filters change
  React.useEffect(() => {
   loadInvitationSummary();
  }, [customerFilter, companyFilter, stageFilter]);

    // Unique customers / companies for filters
    const uniqueCustomers = React.useMemo(() => {
      const names = new Set();
      for (const r of responses) {
        if (r.customerName && r.customerName.trim()) {
          names.add(r.customerName.trim());
        }
      }
      return Array.from(names).sort();
    }, [responses]);

    const uniqueCompanies = React.useMemo(() => {
      const names = new Set();
      for (const r of responses) {
        const name = (r.businessName || r.companyName || "").trim();
        if (name) {
          names.add(name);
        }
      }
      return Array.from(names).sort();
    }, [responses]);

    // Apply global filters: customer + company + result type + (optionally) stage
    const filteredResponses = React.useMemo(() => {
      let rows = responses;

      if (customerFilter !== "ALL") {
        rows = rows.filter(
          (r) => (r.customerName || "").trim() === customerFilter
        );
      }

      if (companyFilter !== "ALL") {
        rows = rows.filter((r) => {
          const name = (r.businessName || r.companyName || "").trim();
          return name === companyFilter;
        });
      }

      if (resultType === "OVERALL") {
        rows = rows.filter((r) => (r.stage || "").trim() === "Overall NPS");
      } else if (resultType === "MILESTONE") {
        rows = rows.filter(
          (r) =>
            r.stage &&
            r.stage.trim() !== "" &&
            r.stage.trim() !== "Overall NPS"
        );
      }

      // 🔹 NEW: global stage filter (applies where relevant)
      if (stageFilter !== "ALL") {
        rows = rows.filter(
          (r) => (r.stage || "").trim() === stageFilter
        );
      }

      return rows;
    }, [responses, customerFilter, companyFilter, stageFilter, resultType]);

  // Group by period
  const grouped = React.useMemo(() => {
    if (!filteredResponses.length) return [];

    const now = new Date();
    const groupsMap = new Map();

    for (const r of filteredResponses) {
      if (!r.createdAt) continue;
      const d = new Date(r.createdAt);
      if (Number.isNaN(d.getTime())) continue;

      let key;
      let label;

      if (period === "monthly") {
        key = getMonthKey(d);
        label = key;
      } else if (period === "quarterly") {
        key = getQuarterKey(d);
        label = key;
      } else {
        // rolling12 → put everything from last 12 months into a single bucket
        const twelveMonthsAgo = new Date(
          now.getFullYear(),
          now.getMonth() - 11,
          1
        );
        if (d < twelveMonthsAgo) continue;
        key = "last-12";
        label = "Last 12 months";
      }

      if (!groupsMap.has(key)) {
        groupsMap.set(key, []);
        groupsMap.get(key).label = label;
      }
      groupsMap.get(key).push(r);
    }

    const result = [];
    for (const [key, arr] of groupsMap.entries()) {
      const stats = computeNpsStats(arr);
      result.push({
        key,
        label: groupsMap.get(key).label || key,
        stats,
      });
    }

    result.sort((a, b) => (a.key > b.key ? 1 : -1));
    return result;
  }, [filteredResponses, period]);

  const overallStats = React.useMemo(
    () => computeNpsStats(filteredResponses),
    [filteredResponses]
  );

  const milestoneStats = React.useMemo(() => {
    const map = {};

    const base = filteredResponses.filter(
      (r) =>
        r.stage &&
        r.stage.trim() !== "" &&
        r.stage.trim() !== "Overall NPS"
    );

    STAGES.filter((s) => s !== "Overall NPS").forEach((stage) => {
      const rowsForStage = base.filter(
        (r) => (r.stage || "").trim() === stage
      );
      map[stage] = computeNpsStats(rowsForStage);
    });

    return map;
  }, [filteredResponses]);

  const wordCloudData = React.useMemo(
    () => buildWordCloudData(filteredResponses),
    [filteredResponses]
  );

  // Stage-filtered version of inviteSummary.byStage (for response rate + race chart)
  const stageFilteredInviteStages = React.useMemo(() => {
    if (!inviteSummary || !inviteSummary.byStage) return [];
    const all = inviteSummary.byStage.slice();
    if (stageFilter === "ALL") return all;
    return all.filter((s) => s.stage === stageFilter);
  }, [inviteSummary, stageFilter]);

  return (
    <div>
      {/* Global Filters + Refresh */}
      <div className="flex flex-wrap gap-3 items-center mb-4">
        {/* Contact filter */}
        <div className="flex items-center gap-2">
          <label
            htmlFor="drp-customer-filter"
            className="text-[11px] text-slate-400"
          >
            View for:
          </label>
          <select
            id="drp-customer-filter"
            name="customerFilter"
            value={customerFilter}
            onChange={(e) => setCustomerFilter(e.target.value)}
            className="rounded-2xl border border-slate-800 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-400"
          >
            <option value="ALL">All demo responses</option>
            {uniqueCustomers.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {/* Company filter */}
        <div className="flex items-center gap-2">
          <label
            htmlFor="drp-company-filter"
            className="text-[11px] text-slate-400"
          >
            Company:
          </label>
          <select
            id="drp-company-filter"
            name="companyFilter"
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="rounded-2xl border border-slate-800 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-400"
          >
            <option value="ALL">All companies</option>
            {uniqueCompanies.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {/* Period filter */}
        <div className="flex items-center gap-2">
          <label
            htmlFor="drp-period-filter"
            className="text-[11px] text-slate-400"
          >
            Period:
          </label>
          <select
            id="drp-period-filter"
            name="period"
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="rounded-2xl border border-slate-800 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-400"
          >
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="rolling12">Last 12 months</option>
          </select>
        </div>

        {/* Result type */}
        <div className="flex items-center gap-2">
          <label
            htmlFor="drp-result-type-filter"
            className="text-[11px] text-slate-400"
          >
            Result type:
          </label>
          <select
            id="drp-result-type-filter"
            name="resultType"
            value={resultType}
            onChange={(e) => setResultType(e.target.value)}
            className="rounded-2xl border border-slate-800 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-400"
          >
            <option value="ALL">All</option>
            <option value="OVERALL">Overall NPS only</option>
            <option value="MILESTONE">Milestone NPS only</option>
          </select>
        </div>

        {/* Stage filter (applies where relevant) */}
        <div className="flex items-center gap-2">
          <label
            htmlFor="drp-stage-filter"
            className="text-[11px] text-slate-400"
          >
            Stage:
          </label>
          <select
            id="drp-stage-filter"
            name="stageFilter"
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="rounded-2xl border border-slate-800 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-emerald-400"
          >
            <option value="ALL">All journey stages</option>
            {STAGES.map((stage) => (
              <option key={stage} value={stage}>
                {stage}
              </option>
            ))}
          </select>
        </div>

        <div className="flex-1" />

        {/* Refresh button */}
        <button
          type="button"
          onClick={() => {
            loadResults();
            loadInvitationSummary();
          }}
          disabled={loadingResults}
          className={classNames(
            "inline-flex items-center justify-center rounded-full px-3 py-1.5 text-xs font-semibold border",
            loadingResults
              ? "border-slate-700 text-slate-400 cursor-not-allowed"
              : "border-slate-600 text-slate-100 hover:border-emerald-400"
          )}
        >
          {loadingResults ? "Refreshing…" : "Refresh results"}
        </button>
      </div>

      {/* Results area – errors & empty states */}
      {resultsError && (
        <div className="rounded-2xl border border-rose-500/60 bg-rose-950/40 px-3 py-2 text-xs text-rose-100 mb-3">
          {resultsError}
        </div>
      )}

      {!resultsError && !filteredResponses.length && !loadingResults && (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/70 px-4 py-6 text-sm text-slate-300">
          No demo responses yet.
          <br />
          <span className="text-xs text-slate-500">
            Run the demo, complete the survey from your inbox, then refresh this section.
          </span>
        </div>
      )}

      {loadingResults && !resultsError && (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/70 px-4 py-4 text-sm text-slate-300">
          Loading demo results…
        </div>
      )}

      {/* If we have responses, show NPS sections */}
      {filteredResponses.length > 0 && (
      <div className="space-y-6">
        {/* 🔹 Sticky KPI strip */}
        <div className="sticky top-0 z-10 -mx-4 -mt-2 mb-4 bg-gradient-to-b from-[#0B0F19]/95 via-[#0B0F19]/92 to-transparent backdrop-blur supports-[backdrop-filter]:bg-[#0B0F19]/80">
          <div className="px-4 pt-3 pb-2 flex flex-col gap-3 lg:flex-row lg:items-stretch lg:gap-4">
            {/* Overall NPS */}
            <div className="flex-1 rounded-2xl border border-slate-800 bg-slate-950/80 px-4 py-3 flex items-center justify-between shadow-[0_18px_45px_rgba(0,0,0,0.5)]">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-widest mb-1">
                  {resultType === "MILESTONE"
                    ? "Overall Milestone NPS"
                    : "Overall NPS"}
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-semibold text-slate-50">
                    {overallStats.nps === null ? "–" : overallStats.nps}
                  </span>
                  {overallStats.nps !== null && (
                    <span className="text-sm text-slate-400">NPS</span>
                  )}
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Based on {overallStats.total} responses.
                </p>
              </div>

              <div className="hidden sm:flex flex-col gap-1 text-[11px] text-slate-300 ml-4">
                <div className="flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-rose-500" />
                  <span>
                    Detractors:{" "}
                    <span className="font-semibold">
                      {overallStats.detractors}
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-amber-400" />
                  <span>
                    Passives:{" "}
                    <span className="font-semibold">
                      {overallStats.passives}
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" />
                  <span>
                    Promoters:{" "}
                    <span className="font-semibold">
                      {overallStats.promoters}
                    </span>
                  </span>
                </div>
              </div>
            </div>

            {/* 🔸 Placeholder KPI tiles – response rate, top / bottom customer */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Response rate % – from inviteSummary.overall if present */}
              <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3 py-3 flex flex-col justify-center">
                <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em]">
                  Response rate
                </p>
                <p className="mt-1 text-xl font-semibold text-slate-50">
                  {inviteSummary?.overall?.responseRate ?? "–"}%
                </p>
                <p className="mt-1 text-[11px] text-slate-500">
                  Of demo invitations completed.
                </p>
              </div>

              {/* You can later compute and fill these properly */}
              <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3 py-3 flex flex-col justify-center">
                <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em]">
                  Top customer
                </p>
                <p className="mt-1 text-sm font-semibold text-slate-50 truncate">
                  Coming soon
                </p>
                <p className="mt-1 text-[11px] text-slate-500">
                  Highest average NPS.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3 py-3 flex flex-col justify-center">
                <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em]">
                  Lowest customer
                </p>
                <p className="mt-1 text-sm font-semibold text-slate-50 truncate">
                  Coming soon
                </p>
                <p className="mt-1 text-[11px] text-slate-500">
                  Lowest average NPS.
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* END sticky KPI strip */}

          {/* Period bar “chart” */}
          <div className="space-y-3">
            <p className="text-xs text-slate-400">
              NPS by{" "}
              {period === "monthly"
                ? "month"
                : period === "quarterly"
                ? "quarter"
                : "last 12 months"}
            </p>

  {/* Existing 100% stacked bars */}
  <div className="space-y-3">
    {grouped.map(({ key, label, stats }) => {
      const total = stats.total || 1;
      const detPct = (stats.detractors / total) * 100;
      const pasPct = (stats.passives / total) * 100;
      const proPct = (stats.promoters / total) * 100;

      return (
        <div
          key={key}
          className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3 py-3"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs text-slate-300">
              <span className="font-medium">{label}</span>{" "}
              <span className="text-slate-500">
                • NPS {stats.nps === null ? "–" : stats.nps}
              </span>
            </div>
            <div className="text-[11px] text-slate-500">
              {stats.total} response{stats.total === 1 ? "" : "s"}
            </div>
          </div>

          <div className="h-3 w-full rounded-full bg-slate-900 overflow-hidden flex">
            {detPct > 0 && (
              <div
                style={{ width: `${detPct}%` }}
                className="bg-rose-500"
              />
            )}
            {pasPct > 0 && (
              <div
                style={{ width: `${pasPct}%` }}
                className="bg-amber-400"
              />
            )}
            {proPct > 0 && (
              <div
                style={{ width: `${proPct}%` }}
                className="bg-emerald-400"
              />
            )}
          </div>
        </div>
      );
    })}
  </div>

            {/* 🔹 NEW: stacked volume columns */}
            {grouped.length > 0 && (
              <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-950/80 px-4 py-4">
                <p className="text-[11px] text-slate-400 mb-2">
                  Response volumes by period (stacked column)
                </p>

                {(() => {
                  const maxTotal = Math.max(
                    ...grouped.map(({ stats }) => stats.total || 0),
                    0
                  );

                  if (!maxTotal) {
                    return (
                      <p className="text-[11px] text-slate-500">
                        Once you have responses in multiple periods, this chart will show
                        total volume per period with detractors, passives and promoters stacked.
                      </p>
                    );
                  }

                  return (
                    <div className="flex items-end gap-3 overflow-x-auto pb-2">
                      {grouped.map(({ key, label, stats }) => {
                        const total = stats.total || 0;
                        const heightPct = maxTotal ? (total / maxTotal) * 100 : 0;

                        const detHeight =
                          total > 0 ? (stats.detractors / total) * heightPct : 0;
                        const pasHeight =
                          total > 0 ? (stats.passives / total) * heightPct : 0;
                        const proHeight =
                          total > 0 ? (stats.promoters / total) * heightPct : 0;

                        return (
                          <div
                            key={`${key}-col`}
                            className="flex flex-col items-center gap-1 min-w-[50px]"
                          >
                            <div className="relative h-32 w-7 rounded-md bg-slate-900 overflow-hidden flex flex-col-reverse">
                              {proHeight > 0 && (
                                <div
                                  className="bg-emerald-400"
                                  style={{ height: `${proHeight}%` }}
                                />
                              )}
                              {pasHeight > 0 && (
                                <div
                                  className="bg-amber-400"
                                  style={{ height: `${pasHeight}%` }}
                                />
                              )}
                              {detHeight > 0 && (
                                <div
                                  className="bg-rose-500"
                                  style={{ height: `${detHeight}%` }}
                                />
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 text-center truncate max-w-[60px]">
                              {label}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              {total}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Milestone NPS section, with LOCAL stage filter */}
          <div className="space-y-4 rounded-3xl border border-slate-800 bg-slate-950/80 px-4 py-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
              <p className="text-xs text-slate-400 uppercase tracking-widest">
                Milestone NPS
              </p>
              <p className="text-[11px] text-slate-500">
                Filtered by the global controls above (contact, company, period, result type, stage).
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {STAGES.filter((s) => s !== "Overall NPS")
                .filter((s) =>
                  stageFilter === "ALL" ? true : s === stageFilter
                )
                .map((stage) => {
                  const stats = milestoneStats[stage] || {
                    nps: null,
                    total: 0,
                  };

                  let tone = "bg-slate-950/60 border-slate-800";
                  if (stats.total > 0 && stats.nps !== null) {
                    if (stats.nps > 20) {
                      tone = "bg-emerald-900/40 border-emerald-500/40";
                    } else if (stats.nps < -20) {
                      tone = "bg-rose-900/40 border-rose-500/40";
                    } else {
                      tone = "bg-amber-900/40 border-amber-500/40";
                    }
                  }

                  return (
                    <div
                      key={stage}
                      className={`rounded-2xl border ${tone} p-3 flex flex-col items-center text-center`}
                    >
                      <p className="text-xs text-slate-400 mb-1">{stage}</p>

                      <div className="text-2xl font-semibold text-slate-50 mb-1">
                        {stats.nps === null ? "–" : stats.nps}
                      </div>

                      <p className="text-[11px] text-slate-500">
                        {stats.total} response{stats.total === 1 ? "" : "s"}
                      </p>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Verbatim tag cloud */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950/80 px-4 py-4">
            <p className="text-xs text-slate-400 uppercase tracking-widest mb-2">
              Verbatim themes (from comments)
            </p>
            <p className="text-sm text-slate-300 mb-4">
              This tag cloud scales each word by how often it appears in the comments for the current filters (contact, company, stage, period, and result type). In a live programme
              you&apos;d use this as a starting point for theme coding.
            </p>

            {wordCloudData.length === 0 ? (
              <p className="text-xs text-slate-500">
                Once a few demo comments have been submitted, key words will start to appear
                here, with more frequent words shown slightly larger.
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {wordCloudData.map((item) => (
                  <span
                    key={item.word}
                    className="rounded-full bg-slate-900/80 border border-slate-700 px-2 py-1 text-slate-100"
                    style={{ fontSize: `${item.fontSize}rem` }}
                    title={`${item.count} occurrence${item.count > 1 ? "s" : ""}`}
                  >
                    {item.word}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Invitation funnel / response rate */}
      {inviteError && (
        <div className="rounded-2xl border border-rose-500/60 bg-rose-950/40 px-3 py-2 text-xs text-rose-100 mb-3">
          {inviteError}
        </div>
      )}

      {inviteSummary && !inviteError && (
        <div className="space-y-4 mt-6">
          {/* Overall funnel card */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950/80 px-4 py-4 flex flex-wrap gap-4 items-center justify-between">
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-widest mb-1">
                Invitation funnel (demo)
              </p>
              <h3 className="text-sm font-semibold text-slate-50">
                How many invitations turned into completed surveys?
              </h3>
              <p className="mt-1 text-[11px] text-slate-500 max-w-sm">
                This shows the basic response funnel for the demo environment. In a live
                programme, we add opens and survey starts so you can see where drop-off happens.
              </p>
            </div>

            {(() => {
              const overall = inviteSummary.overall || {
                sent: 0,
                opened: 0,
                started: 0,
                completed: 0,
                startRate: null,
                responseRate: null,
              };

              const sent = overall.sent || 0;
              const started = overall.started || 0;
              const completed = overall.completed || 0;

              return (
                <div className="flex flex-col gap-1 text-xs text-slate-200 min-w-[200px]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Invitations sent</span>
                    <span className="font-semibold">{sent}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Opened / started*</span>
                    <span className="font-semibold">
                      {started} {sent > 0 ? `(${overall.startRate ?? "-"}%)` : ""}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Completed surveys</span>
                    <span className="font-semibold">
                      {completed}{" "}
                      {sent > 0 ? `(${overall.responseRate ?? "-"}%)` : ""}
                    </span>
                  </div>

                  <div className="mt-2 h-2 w-full rounded-full bg-slate-900 overflow-hidden flex">
                    {sent > 0 && (
                      <div
                        className="bg-emerald-400 transition-all"
                        style={{
                          width: `${Math.min(100, (completed / sent) * 100 || 0)}%`,
                        }}
                      />
                    )}
                  </div>

                  <p className="mt-1 text-[10px] text-slate-500">
                    *For now, “opened / started” uses survey starts; in a full build this
                    would include email opens.
                  </p>
                </div>
              );
            })()}
          </div>

          {/* Response rate by stage – uses stageFilter */}
          {stageFilteredInviteStages.length > 0 && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950/80 px-4 py-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                <p className="text-xs text-slate-400 uppercase tracking-widest">
                  Response rate by journey stage
                </p>
                <p className="text-[11px] text-slate-500">
                  Uses the same filters as the top of the cockpit, including Stage.
                </p>
              </div>

              <p className="text-[11px] text-slate-500 mb-3">
                Each bar shows what proportion of invitations for that stage turned into
                completed surveys. Use this to see which parts of the journey people are
                most willing to give feedback on.
              </p>

              <div className="space-y-2">
                {stageFilteredInviteStages
                  .slice()
                  .sort((a, b) => {
                    const aRate = a.sent > 0 ? a.completed / a.sent : 0;
                    const bRate = b.sent > 0 ? b.completed / b.sent : 0;
                    return bRate - aRate;
                  })
                  .map((stage) => {
                    const sent = stage.sent || 0;
                    const completed = stage.completed || 0;
                    const rate =
                      sent > 0 ? Math.round((completed / sent) * 100) : null;

                    return (
                      <div key={stage.stage} className="space-y-1">
                        <div className="flex items-center justify-between text-[11px] text-slate-300">
                          <span>{stage.stage}</span>
                          <span className="text-slate-400">
                            {completed}/{sent} {rate === null ? "" : `• ${rate}%`}
                          </span>
                        </div>
                        <div className="h-2 w-full rounded-full bg-slate-900 overflow-hidden">
                          {sent > 0 && (
                            <div
                              className="h-full bg-emerald-400 transition-all"
                              style={{
                                width: `${Math.min(
                                  100,
                                  (completed / sent) * 100 || 0
                                )}%`,
                              }}
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {/* Race chart: response volume by stage – also stage-filtered */}
          {stageFilteredInviteStages.length > 0 && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950/80 px-4 py-4">
              <p className="text-xs text-slate-400 uppercase tracking-widest mb-2">
                Response volume “race” (by stage)
              </p>
              <p className="text-[11px] text-slate-500 mb-3">
                Stages with more completed surveys have longer bars. In a live programme, this
                can help you see where most of your feedback is coming from at a glance.
              </p>

              {(() => {
                const stages = stageFilteredInviteStages.filter(
                  (s) => (s.completed || 0) > 0
                );

                if (!stages.length) {
                  return (
                    <p className="text-[11px] text-slate-500">
                      Once a few demo invitations have been completed, you&apos;ll see a
                      bar race here showing which stages generate the most feedback.
                    </p>
                  );
                }

                const maxCompleted = Math.max(
                  ...stages.map((s) => s.completed || 0)
                );

                return (
                  <div className="space-y-2">
                    {stages
                      .slice()
                      .sort((a, b) => (b.completed || 0) - (a.completed || 0))
                      .map((stage) => {
                        const completed = stage.completed || 0;
                        const widthPct = maxCompleted
                          ? (completed / maxCompleted) * 100
                          : 0;

                        return (
                          <div
                            key={stage.stage}
                            className="flex items-center gap-3 text-[11px]"
                          >
                            <div className="w-28 text-slate-300 truncate">
                              {stage.stage}
                            </div>
                            <div className="flex-1 h-2 rounded-full bg-slate-900 overflow-hidden">
                              <div
                                className="h-full bg-violet-400/90 transition-all"
                                style={{ width: `${Math.min(100, widthPct)}%` }}
                              />
                            </div>
                            <div className="w-10 text-right text-slate-300">
                              {completed}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
